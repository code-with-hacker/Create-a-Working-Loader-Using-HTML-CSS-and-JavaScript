$(window).load(function(){
    $("#loader").delay(100).fadeOut(100);
    $("#content").fadeIn(100);
});